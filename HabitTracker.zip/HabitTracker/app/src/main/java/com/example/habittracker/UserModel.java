package com.example.habittracker;

public class UserModel {
    String username,email_id,user_id;

    UserModel(String username,String email_id,String user_id){
        this.username=username;
        this.email_id=email_id;
        this.user_id = user_id;
    }
}
