package com.example.habittracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

public class MainActivity extends AppCompatActivity {

    Button logout_btn;
    TextView register_tv;
    FirebaseAuth mAuth;

    ChipNavigationBar bottomNav;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logout_btn=findViewById(R.id.logout_mainact_btn);
        mAuth=FirebaseAuth.getInstance();
        bottomNav=findViewById(R.id.bottom_nav);

        if(savedInstanceState==null)
        {
            bottomNav.setItemSelected(R.id.home,true);
            fragmentManager=getSupportFragmentManager();
            Home_Fragment homeFragment=new Home_Fragment();
            fragmentManager.beginTransaction().replace(R.id.fragment_container,homeFragment).commit();
        }

        bottomNav.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int id) {
                Fragment fragment=null;
                switch (id)
                {
                    case R.id.home:
                        fragment=new Home_Fragment();
                        break;
                    case R.id.create:
                        fragment=new Create_New_Habit_Fragment();
                        break;
                    case R.id.account:
                        fragment=new Account_Fragment();
                        break;
                }

                if(fragment!=null)
                {
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.fragment_container,fragment).commit();
                }else {
                    Log.e("error","Error in creating fragment");
                }

            }
        });

        logout_btn.setOnClickListener(view -> {
            mAuth.signOut();
            Toast.makeText(MainActivity.this,"LoggedOut successfully",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,Login_Activity.class));
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user=mAuth.getCurrentUser();
        if (user==null)
        {
            startActivity(new Intent(MainActivity.this,Login_Activity.class));
        }
    }
//
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//    }
}
