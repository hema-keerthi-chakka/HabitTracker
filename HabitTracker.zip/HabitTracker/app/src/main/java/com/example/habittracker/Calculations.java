package com.example.habittracker;

import java.util.Date;
import java.util.HashMap;

public class Calculations {
    Calculations(){ }

    public Integer countStreak(Date beg, Date end, HashMap<Date,Boolean> map)
    {
        Integer cur_count=0,highest=0;
        //iterate through each date from beginning to end , get date from map
        // Use kadane's algorithm to get max streak
        return cur_count;
    }

}
