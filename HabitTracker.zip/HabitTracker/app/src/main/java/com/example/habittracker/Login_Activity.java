package com.example.habittracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_Activity extends AppCompatActivity {

    Button login_btn;
    TextView forgotpassword;
    FirebaseAuth mAuth;
    EditText email_et,password_et;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email_et=findViewById(R.id.tv);
        password_et=findViewById(R.id.password_et);
        login_btn=findViewById(R.id.login_btn);
        forgotpassword=findViewById(R.id.forgot_pass_tv);
        mAuth=FirebaseAuth.getInstance();

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Forgot_Password.class));

            }
        });


        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginuser();
            }
        });

    }

    private void loginuser() {
        String email=email_et.getText().toString();
        String password=password_et.getText().toString();
        if(TextUtils.isEmpty(email))
        {
            email_et.setError("Email cannot be empty");
            email_et.requestFocus();
        } else if(TextUtils.isEmpty(password))
        {
            password_et.setError("Password cannot be empty");
            password_et.requestFocus();
        }else{
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(Login_Activity.this,"Login successful",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(Login_Activity.this, MainActivity.class));
                    }
                    else{
                        email_et.setError("Invalid credentials");
                        password_et.requestFocus();
                        Toast.makeText(Login_Activity.this,"Login error :"+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

    }

    public void goto_register(View view) {
        Intent i=new Intent(this, Register_Activity.class);
//        startActivity(new Intent(this, Forgot_Password.class));
        startActivity(i);
    }
}