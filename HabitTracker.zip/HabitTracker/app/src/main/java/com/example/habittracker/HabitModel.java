package com.example.habittracker;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class HabitModel {
    String title,description;
    Date beginningDate,endDate;
    Integer maxStreak,curStreak;

    HashMap<Date,Boolean> map=new HashMap<>();

    HabitModel(String title, String description) //, Date beginningDate,Date endDate)
    {
        this.title=title;
        this.description=description;
//        this.beginningDate=beginningDate;
//        this.endDate=endDate;
//        this.map.put(this.beginningDate,false);
    }
}

