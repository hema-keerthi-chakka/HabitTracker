package com.example.habittracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Register_Activity extends AppCompatActivity {

    Button signin_btn;
    EditText name_et,email_et,password_et,confirm_password_et;
    FirebaseAuth mAuth;
    FirebaseDatabase firebaseDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_);

        signin_btn=findViewById(R.id.login_btn);
        name_et=findViewById(R.id.name_et);
        email_et=findViewById(R.id.email_et);
        password_et=findViewById(R.id.password_et);
        confirm_password_et=findViewById(R.id.confirm_password_et);
        mAuth=FirebaseAuth.getInstance();


        signin_btn.setOnClickListener(view -> {
            createUser();
        });

    }

    private void createUser() {
        String email=email_et.getText().toString();
        String name=name_et.getText().toString();
        String password=password_et.getText().toString();
        String cf_password=confirm_password_et.getText().toString();

        if(TextUtils.isEmpty(name))
        {
            name_et.setError("Name cannot be empty");
            name_et.requestFocus();
        }else if(TextUtils.isEmpty(email))
        {
            email_et.setError("Email cannot be empty");
            email_et.requestFocus();
        } else if(TextUtils.isEmpty(password) || password.length()<6)
        {
            password_et.setError("Password length can't be less than zero");
            password_et.requestFocus();
        }else if(TextUtils.isEmpty(cf_password) || (!cf_password.equals(password)))
        {
            confirm_password_et.setError("Passwords aren't matching.");
            confirm_password_et.requestFocus();
        }else{
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        //getting user unique id
                        String user_id=FirebaseAuth.getInstance().getCurrentUser().getUid();
                        //creating user class. personal details
                        UserModel user= new UserModel(name,email,user_id);
                        Toast.makeText(Register_Activity.this,"User class created",Toast.LENGTH_SHORT).show();

                        //inserting user data fro the first time
                        FirebaseDatabase.getInstance().getReference("Users").child(user_id).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){

                                    Toast.makeText(Register_Activity.this,"User registered successfully",Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(Register_Activity.this, MainActivity.class));
                                }
                                else {
                                    Toast.makeText(Register_Activity.this,"Failed to register . Try again.",Toast.LENGTH_LONG).show();
                                }
                            }
                        });

                    //creating user error.
                    }
                    else{
                        Toast.makeText(Register_Activity.this,"User registration error :"+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }

    public void goto_login(View view) {
        Intent i=new Intent(Register_Activity.this,Login_Activity.class);
        startActivity(i);
    }
}



