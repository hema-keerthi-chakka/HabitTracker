package com.example.habittracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class Forgot_Password extends AppCompatActivity {

    EditText email;
    Button resetpw;
    ProgressBar pb;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);
        email=(EditText) findViewById(R.id.email);
        resetpw=(Button) findViewById(R.id.resetpassword);
        pb=(ProgressBar) findViewById(R.id.progressBar);
        auth= FirebaseAuth.getInstance();
        resetpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetpassword();
            }
        });

    }

    public void resetpassword()
    {
        String emailid=email.getText().toString().trim();
        if(emailid.isEmpty()){
            email.setError("email is required");
            email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(emailid).matches()){
            email.setError("please provide valid email");
            email.requestFocus();
            return;
        }
        pb.setVisibility(View.VISIBLE);
        auth.sendPasswordResetEmail(emailid).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Forgot_Password.this, "check your email to reset password", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(Forgot_Password.this, "try again", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}