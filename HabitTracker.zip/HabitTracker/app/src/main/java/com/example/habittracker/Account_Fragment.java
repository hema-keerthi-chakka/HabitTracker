package com.example.habittracker;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Account_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Account_Fragment extends Fragment {

    Button logout_btn;
    FirebaseAuth mAuth;
    FirebaseUser user;
    DatabaseReference reference;
    String user_id;

    EditText name,email,password;
    TextView maxStreak,curStreak;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Account_Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AccountFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Account_Fragment newInstance(String param1, String param2) {
        Account_Fragment fragment = new Account_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(R.layout.fragment_account, container, false);

        name=myView.findViewById(R.id.et_PersonName_acc);
        email=myView.findViewById(R.id.et_email_acc);
        password=myView.findViewById(R.id.et_password_acc);


        logout_btn=myView.findViewById(R.id.logout_btn);
        mAuth= FirebaseAuth.getInstance();
        user=mAuth.getCurrentUser();
        //reference=FirebaseDatbase........error anyhow
        user_id=user.getUid();

        //get name email password from database by adding datalisteners and retrieving from snapshot
        // link to follow : https://www.youtube.com/watch?v=-plgl1EQ21Q

        String display_name= null; //get;
        String display_email=null; //get
        String display_password=null;//get



        name.setText(display_name);
        email.setText(display_email);
        password.setText(display_password);



        logout_btn.setOnClickListener(view -> {
            mAuth.signOut();
            Toast.makeText(getActivity(),"LoggedOut successfully",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getActivity(),Login_Activity.class));
        });

        return myView;
    }
}